# ML Classification Project

## Project Title
Email Spam Detection Using Machine Learning

## Objective
To classify SMS messages as spam or ham using machine learning algorithms.

## Technologies Used
- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn

## Algorithms Used
1. Logistic Regression
2. Random Forest

## Run Project

```bash
python ml_classification.py
```
