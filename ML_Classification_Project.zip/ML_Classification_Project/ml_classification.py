import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
    roc_curve
)

# LOAD DATASET
data = pd.read_csv(
    "spam.csv",
    sep='\t',
    names=["label", "message"]
)

print("\nFirst 5 Rows:\n")
print(data.head())

# DATA PREPROCESSING
data['label'] = data['label'].map({
    'ham': 0,
    'spam': 1
})

X = data['message']
y = data['label']

vectorizer = TfidfVectorizer(stop_words='english')
X_vectorized = vectorizer.fit_transform(X)

# TRAIN TEST SPLIT
X_train, X_test, y_train, y_test = train_test_split(
    X_vectorized,
    y,
    test_size=0.2,
    random_state=42
)

# MODEL 1
lr_model = LogisticRegression()
lr_model.fit(X_train, y_train)

lr_pred = lr_model.predict(X_test)
lr_prob = lr_model.predict_proba(X_test)[:, 1]

# MODEL 2
rf_model = RandomForestClassifier()
rf_model.fit(X_train, y_train)

rf_pred = rf_model.predict(X_test)
rf_prob = rf_model.predict_proba(X_test)[:, 1]

# EVALUATION
def evaluate_model(name, y_test, pred, prob):

    print(f"\n{name} Results")
    print("-" * 40)

    accuracy = accuracy_score(y_test, pred)
    precision = precision_score(y_test, pred)
    recall = recall_score(y_test, pred)
    f1 = f1_score(y_test, pred)
    roc_auc = roc_auc_score(y_test, prob)

    print("Accuracy :", accuracy)
    print("Precision:", precision)
    print("Recall   :", recall)
    print("F1 Score :", f1)
    print("ROC-AUC  :", roc_auc)

    print("\nClassification Report:\n")
    print(classification_report(y_test, pred))

    return accuracy, precision, recall, f1, roc_auc

# EVALUATE MODELS
lr_metrics = evaluate_model(
    "Logistic Regression",
    y_test,
    lr_pred,
    lr_prob
)

rf_metrics = evaluate_model(
    "Random Forest",
    y_test,
    rf_pred,
    rf_prob
)

# CROSS VALIDATION
print("\nCross Validation Scores")

lr_cv = cross_val_score(
    lr_model,
    X_vectorized,
    y,
    cv=5
)

rf_cv = cross_val_score(
    rf_model,
    X_vectorized,
    y,
    cv=5
)

print("\nLogistic Regression CV Accuracy:", lr_cv.mean())
print("Random Forest CV Accuracy:", rf_cv.mean())

# CONFUSION MATRIX
cm = confusion_matrix(y_test, rf_pred)

plt.figure(figsize=(6, 5))

sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    cmap='Blues'
)

plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")

plt.show()

# ROC CURVE
fpr, tpr, thresholds = roc_curve(
    y_test,
    rf_prob
)

plt.figure(figsize=(6, 5))

plt.plot(
    fpr,
    tpr,
    label='Random Forest'
)

plt.plot(
    [0, 1],
    [0, 1],
    linestyle='--'
)

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")

plt.title("ROC Curve")

plt.legend()
plt.show()

# FINAL COMPARISON
comparison = pd.DataFrame({
    'Metric': [
        'Accuracy',
        'Precision',
        'Recall',
        'F1 Score',
        'ROC-AUC'
    ],
    'Logistic Regression': lr_metrics,
    'Random Forest': rf_metrics
})

print("\nModel Comparison:\n")
print(comparison)
